import { Component } from '@angular/core';
import { ParentUser } from './parent-user.interface';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  parentUsers: ParentUser[] = [
    { Id: 1, Firstname: 'Mariam', Lastname: 'Khuroshvili', DateOfBirth: new Date('2002-01-01'), PhoneNumber: '598457312', Email: 'wolfkhuroia@gmail.com' },
  
    { Id: 2, Firstname: 'Luka', Lastname: 'Gobechia', DateOfBirth: new Date('2005-06-14'), PhoneNumber: '568102514', Email: 'gobechia7@hmail.com' },
    
    { Id: 3, Firstname: 'Tsitsi', Lastname: 'Cabutidze', DateOfBirth: new Date('1990-07-22'), PhoneNumber: '598100212', Email: 'tsitsilovecs@gmail.com' },

    { Id: 4, Firstname: 'Khatia', Lastname: 'Turmanidze', DateOfBirth: new Date('2006-04-30'), PhoneNumber: '557332688', Email: 'khatiamagaria@gmail.com' },
    
    { Id: 5, Firstname: 'Sesili', Lastname: 'Tskhadaia', DateOfBirth: new Date('1995-01-15'), PhoneNumber: '593123897', Email: 'greenrat@gmail.com' },
  ];

}
