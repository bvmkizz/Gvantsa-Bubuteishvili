// parent-user.interface.ts
export interface ParentUser {
    Id: number;
    Firstname: string;
    Lastname: string;
    DateOfBirth: Date;
    PhoneNumber: string;
    Email: string;
  }
  
